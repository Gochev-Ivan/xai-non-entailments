# =============================================================================
def pathfinder(A):
    indexes = []  # input
    paths = []  # output
    
    # Find all paths on depth = 0:
    for j in range(len(A)):
        
        if A[0][j] == 1:
            
            indexes.append(j)
            paths.append([0, j])
    
    # Find all remaining paths:
    while len(indexes) > 0:
        
        # Get the next index:
        idx = indexes.pop(0)
        
        if idx >= len(A): continue
        
        # Check all possible branches:
        for k in range(len(A[idx])):
            
            if A[idx][k] == 1:
                
                i = 0
                temp_paths = paths.copy()
                
                while i < len(temp_paths):
                    
                    if idx == temp_paths[i][len(temp_paths[i]) - 1]:
                        
                        temp = paths[i].copy()
                        temp.append(k)
                        paths.append(temp)
                    
                    i += 1
                
                indexes.append(k)
    
    return paths
# =============================================================================

# =============================================================================
def set_of_all_complete_paths(T):
    
    # Get the adjacency matrix of the tree:
    A = T.adjacency_matrix()
    
    # Find all paths in the tree:
    paths = pathfinder(A)
    
    # Define and initialize the variable complete_paths:
    complete_paths = []
    
    # Find all complete paths:
    for p in paths:
        
        # Get the final vertex of the path:
        v = p[-1]
        
        # If final vertex is a leaf we found a complete path:
        if set(A[v]) == {0}: complete_paths.append(p)
    
    return complete_paths
# =============================================================================

# =============================================================================
def set_of_all_complete_paths_of_adj_matrix(A):
    
    # Find all paths in the tree:
    paths = pathfinder(A)
    
    # Define and initialize the variable complete_paths:
    complete_paths = []
    
    # Find all complete paths:
    for p in paths:
        
        # Get the final vertex of the path:
        v = p[-1]
        
        # If final vertex is a leaf we found a complete path:
        if set(A[v]) == {0}: complete_paths.append(p)
    
    return complete_paths
# =============================================================================

# =============================================================================
def set_of_all_complete_paths_with_edge_labels(T, vertex_naming):
    # Get all complete paths from the tree T:
    complete_paths = [[f'{vertex_naming}{vertex_idx}' for vertex_idx in path] 
                      for path in set_of_all_complete_paths(T)]
    
    # Define variable in which the complete paths will be stored:
    CP = []
    
    # Iterate over all complete paths of the tree
    for path in complete_paths:
        
        # Define a temp variable in which paths will be stored:
        x = []
        
        # Iterate over all pairs of vertices in the current path:
        for i in range(len(path) - 1):
            
            # If the predecessor vertex is not added in the path:
            if path[i] not in x:
                
                # Add the vertex:
                x.append(path[i])
            
            # Add the edge label between vertices enumerated as i and i + 1:
            x.append(T.l_e[(path[i], path[i + 1])])
            
            # If the successor vertex is not added in the path:
            if path[i + 1] not in x:
                
                # Add the vertex:
                x.append(path[i + 1])
        
        # Save the current complete path:
        CP.append(x)
    
    return CP
# =============================================================================
