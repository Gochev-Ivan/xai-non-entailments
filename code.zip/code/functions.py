from pathfinder import set_of_all_complete_paths
from math import factorial
import numpy as np

def print_matrix(A):
    
    for x in A:
        for y in x:
            print(y, end=' ')
        print()

def print_dict(D):
    for key, val in D.items():
        print(f'{key} --> {val}')

# def get_avg_edge_labels_branching_factor(edge_depths_T1, edge_depths_T2):
#     """ NOT COMPLETE """
#     avg_common_edge_labels_on_same_depths = []
    
#     common_keys = set(edge_depths_T1.keys()).intersection(set(edge_depths_T2.keys()))
    
#     common_edge_labels_on_same_depths = []
#     for key in common_keys:
        
#         common_edge_labels_on_same_depths = list(filter(lambda x: x in edge_depths_T1[key] and edge_depths_T2[key], edge_depths_T1[key] + edge_depths_T2[key]))
    
#     return avg_common_edge_labels_on_same_depths

def create_non_entailment_concepts(T1, T2):
    paths1 = set_of_all_complete_paths(T1)
    paths2 = set_of_all_complete_paths(T2)
    
    reversed_paths1 = {v : k for k, v in T1.Em.items()}
    reversed_paths2 = {v : k for k, v in T2.Em.items()}
    
    for x in paths1:
        
        reversed_x = list(reversed(x))
        # print(reversed_x)
        s = ''
        
        for y in range(len(reversed_x) - 1):
            v1, v2 = reversed_paths1[(reversed_x[y + 1], reversed_x[y])]
            # print("els : ", v1, v2, T1.l_v[v1], T1.l_v[v2])
            
            if len(T1.l_v[v2]) > 1:
                s = ''
                cnt = 0
                for el in T1.l_v[v2]:
                    if cnt + 1 == len(T1.l_v[v2]):
                        s += f'{el})'
                    else:
                        s += f'{el} & '
                    cnt += 1
                T1.l_v[v1].add(f'(onto.{T1.l_e[(v1, v2)]}.some(' + s + ')')
                # T1.l_v[L1[0][0]].add(f'{L1[1]}.some(' + s)
            elif len(T1.l_v[v2]) == 1:
                el = list(T1.l_v[v2])[0]
                s = f'{el}'
                T1.l_v[v1].add(f'(onto.{T1.l_e[(v1, v2)]}.some(' + s + '))')
                # T1.l_v[L1[0][0]].add(f'{L1[1]}.some(' + s)
    
    cnt = 0
    concept1 = ''
    for el in T1.l_v['v0']:
        if cnt + 1 == len(T1.l_v['v0']):
            concept1 += el
        else:
            concept1 += el + ' & '
        cnt += 1
    
    for x in paths2:
        
        reversed_x = list(reversed(x))
        s = ''
        if len(reversed_x) > 2:
            ...
        
        else:
            for y in range(len(reversed_x) - 1):
                v1, v2 = reversed_paths2[(reversed_x[y + 1], reversed_x[y])]
                
                if len(T2.l_v[v2]) > 1:
                    s = ''
                    cnt = 0
                    for el in T2.l_v[v2]:
                        if cnt + 1 == len(T2.l_v[v2]):
                            s += f'{el})'
                        else:
                            s += f'{el} & '
                        cnt += 1
                    T2.l_v[v1].add(f'(onto.{T2.l_e[(v1, v2)]}.some(' + s + ')')
                    # T1.l_v[L1[0][0]].add(f'{L1[1]}.some(' + s)
                elif len(T2.l_v[v2]) == 1:
                    el = list(T2.l_v[v2])[0]
                    s = f'{el}'
                    T2.l_v[v1].add(f'(onto.{T2.l_e[(v1, v2)]}.some(' + s + '))')
                    # T1.l_v[L1[0][0]].add(f'{L1[1]}.some(' + s)
    
    cnt = 0
    concept2 = ''
    for el in T2.l_v['w0']:
        if cnt + 1 == len(T2.l_v['w0']):
            concept2 += el
        else:
            concept2 += el + ' & '
        cnt += 1
    
    return concept1, concept2

def create_non_entailment_concepts_1(T1, T2):
    C1, C2 = '', ''
    
    T1.l_v = {f'v{i}' : {f'onto.A{i}'} for i in range(0, len(T1.V))}
    T2.l_v = {f'w{i}' : {f'onto.B{i}'} for i in range(0, len(T2.V))}
    
    A1 = T1.adjacency_matrix_v1()
    A2 = T2.adjacency_matrix_v1()
    
    for i, row in A1.iloc[::-1].iterrows():
        for j, el in row.items():
            # print(f'i = {i}, j = {j}, el = {el}')
            if el != 0:
                s = ''
                cnt = 0
                for k in T1.l_v[j]:
                    if cnt + 1 == len(T1.l_v[j]):
                        s += f'{k})'
                    else:
                        s += f'{k} & '
                    cnt += 1
                T1.l_v[i].add(f'(onto.{el}.some(' + s + ')')
    cnt = 0
    for el in T1.l_v['v0']:
        if cnt + 1 == len(T1.l_v['v0']):
            C1 += el
        else:
            C1 += el + ' & '
        cnt += 1
        
    for i, row in A2.iloc[::-1].iterrows():
        for j, el in row.items():
            # print(f'i = {i}, j = {j}, el = {el}')
            if el != 0:
                s = ''
                cnt = 0
                for k in T2.l_v[j]:
                    if cnt + 1 == len(T2.l_v[j]):
                        s += f'{k})'
                    else:
                        s += f'{k} & '
                    cnt += 1
                T2.l_v[i].add(f'(onto.{el}.some(' + s + ')')
    cnt = 0
    for el in T2.l_v['w0']:
        if cnt + 1 == len(T2.l_v['w0']):
            C2 += el
        else:
            C2 += el + ' & '
        cnt += 1
    
    return C1, C2

def get_avg_edge_labels_branching_factor(edge_depths_T1, edge_depths_T2):
    """ NOT COMPLETE """
    avg_common_edge_labels_on_same_depths = []
    
    common_keys = set(edge_depths_T1.keys()).intersection(set(edge_depths_T2.keys()))
    
    # print(common_keys)
    
    common_edge_labels_on_same_depths = []
    for key in common_keys:
        
        common_edge_labels_on_same_depths = list(filter(lambda x: x in edge_depths_T1[key] and edge_depths_T2[key], edge_depths_T1[key] + edge_depths_T2[key]))
            
    # print(common_edge_labels_on_same_depths)
    
    return avg_common_edge_labels_on_same_depths

def find_max_freq_of_common_edge_labels_on_same_depths(T1, T2):
    role_depths_1 = {v : [] for k, v in T1.l_e.items()}
    
    for k, v in T1.l_e.items():
        role_depths_1[v].append(((T1.depths[k[0]] + T1.depths[k[1]]) / 2))
    
    role_depths_2 = {v : [] for k, v in T2.l_e.items()}
    
    for k, v in T2.l_e.items():
        role_depths_2[v].append(((T2.depths[k[0]] + T2.depths[k[1]]) / 2))
    
    common_roles = {}
    
    for key in role_depths_1.keys():
        
        if key in role_depths_2.keys():
            
            count_roles_1 = [(x, role_depths_1[key].count(x)) 
                             for x in set(role_depths_1[key])]
            
            count_roles_2 = [(x, role_depths_2[key].count(x)) 
                             for x in set(role_depths_2[key])]
            
            common_roles[key] = []
            
            for x in count_roles_1:
                
                for y in count_roles_2:
                    
                    if x[0] == y[0]:
                        
                        
                        
                        if x[1] > y[1]: 
                            
                            common_roles[key].append(x[1])
                        
                        if x[1] <= y[1]:
                            
                            common_roles[key].append(y[1])
    
    all_common_roles = []
    max_common_role = (0, -1)
    for key, val in common_roles.items():
        
        if len(val) != 0:
            if max(val) >= max_common_role[1]:
                
                max_common_role = (key, val[0])
                
                all_common_roles.append(max_common_role)
    
    f_e = list(filter(lambda x: x[1] > 1, all_common_roles))
    # f_1 = list(filter(lambda x: x[1] <= 1, all_common_roles))
    
    num_h = 0
    
    if len(f_e) > 0:
        
        sum_e = 0
        
        for e in f_e:
            
            sum_e += factorial(e[1])
    
        num_h = sum_e
    else:
        
        num_h = 1
            
    return max_common_role, all_common_roles, num_h
