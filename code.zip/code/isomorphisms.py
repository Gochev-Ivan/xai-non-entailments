# =============================================================================
""" Libraries: """
import time
import itertools
import numpy as np
import pandas as pd
from sympy import poly, var, simplify, factor, Symbol
from pathfinder import pathfinder
from pathfinder import set_of_all_complete_paths
from pathfinder import set_of_all_complete_paths_with_edge_labels
from pathfinder import set_of_all_complete_paths_of_adj_matrix
from functions import print_matrix
from functions import print_dict
import functools
# =============================================================================

# =============================================================================
def f(A, row, v):
    # Construct the polynomial f:
    poly = dict()
    
    for vertex in row:
        
        if A.loc[v, vertex] not in poly.keys():
            
           poly[A.loc[v, vertex]] = [vertex]
           
        else:
            
            poly[A.loc[v, vertex]].append(vertex)
    
    return poly

def map_func(search, search_space):
    # Save all mapping combination in a list:
    mapping_comb = []
    
    # Iterate over each vertex of T1 found in the search space:
    for v in search:
        
        # Find all pairs in the search space that contain v:
        comb = list(filter(lambda x: x[0] == v, search_space))
        
        # If the vertex is not found in any combination, continue:
        if len(comb) == 0: continue
        
        # Add the new combination of mappings:
        mapping_comb.append(comb)
    
    # Find all possible combinations of mappings:
    mappings_list = [element for element in itertools.product(*mapping_comb)]
    
    # Filter those combinations that have repeating mappings:
    mappings1 = [m for m in mappings_list 
                 if len(set([x[1] for x in m])) == len([x[1] for x in m])]
    
    return mappings1

# =============================================================================
def contract_subsequent_nodes(nodes_to_contract, T1, T2, df_A1, df_A2):
    
    additional_nodes_to_contract = []
    
    for x in nodes_to_contract:
        
        # If the current node is from T2:
        if x in T2.V:
            
            nodes_to_contract_in_T2 = []
            
            subsequent_nodes_to_contract_in_T2 = [x]
            
            while len(subsequent_nodes_to_contract_in_T2) != 0:
                
                curr_node = subsequent_nodes_to_contract_in_T2.pop()
                
                # Contract all subsequent nodes:
                nodes_to_contract_in_T2.extend([f'w{y}' for y in np.where(
                    df_A2.loc[curr_node])[0]])
                
                subsequent_nodes_to_contract_in_T2.extend([f'w{y}' 
                                                     for y in np.where(
                    df_A2.loc[curr_node])[0]])
            
            additional_nodes_to_contract.extend(nodes_to_contract_in_T2)
        
        # If the current node is from T1:
        if x in T1.V:
            
            nodes_to_contract_in_T1 = []
            
            subsequent_nodes_to_contract_in_T1 = [x]
            
            while len(subsequent_nodes_to_contract_in_T1) != 0:
                
                curr_node = subsequent_nodes_to_contract_in_T1.pop()
                
                # Contract all subsequent nodes:
                nodes_to_contract_in_T1.extend([f'v{y}' for y in np.where(
                    df_A1.loc[curr_node])[0]])
                
                subsequent_nodes_to_contract_in_T1.extend([f'v{y}' 
                                                     for y in np.where(
                    df_A1.loc[curr_node])[0]])
            
            additional_nodes_to_contract.extend(nodes_to_contract_in_T1)
    
    return additional_nodes_to_contract

def find_isomorphisms_v5(T1, T2):
    # Get the adjacency matrices for T1 and T2, respectively:
    A1, df_A1 = T1.adjacency_matrix(), T1.adjacency_matrix_v1()
    A2, df_A2 = T2.adjacency_matrix(), T2.adjacency_matrix_v1()
    
    start_time = time.time()
    # start_time = time.process_time_ns()
    
    # Construct the polynomials for each vertex in T1 and T2, respectively:
    f1 = {v : f(df_A1, [f'v{x}' for x in np.where(df_A1.loc[v])[0]], v) 
          for v in T1.V}
    
    f2 = {w : f(df_A2, [f'w{x}' for x in np.where(df_A2.loc[w])[0]], w) 
          for w in T2.V}
    
    print('===')
    print_dict(f1)
    print()
    print_dict(f2)
    print('===')
    
    ST_nodes = {0 : [('v0', 'w0')]}
    ST_edges = []
    
    nodes_to_evaluate = [0]
    node_idx = 1
    
    poly_deltas = []
    
    while len(nodes_to_evaluate) != 0:
        
        # Evaluate next node:
        n = nodes_to_evaluate.pop(0)
        
        # Get the current mappings (node from the solutions tree):
        current_mappings = ST_nodes[n]
        
        # If there are no mappings to evaluate, stop the search:
        if len(current_mappings) == 0: break
        
        # Save the nodes that need to be contracted for the current mapping:
        nodes_to_contract = []
        
        # Init the new node in the solutions tree:
        # new_node_ST = []
        
        # Init the unique combinations for a certain node 
        # in the solutions tree:
        unique_combinations_node_ST = []
        
        # Go over subsequent mappings in the current mapping:
        for m in current_mappings:
            
            # If nodes need to be contracted, remember them:
            if m[0] == 0 or m[1] == 0: continue
            
            # If we have have a corresponding mapping:
            if m[0] in T1.V and m[1] in T2.V:
                
                # Iterate over each coefficient of polynomial 1:
                for edge_label in f1[m[0]].keys():
                    
                    # If the coefficient (edge label) from polynomial 1 is not 
                    # found in polynomial 2, contract the nodes (and all 
                    # subsequent nodes) from T1:
                    if edge_label not in f2[m[1]].keys():
                        
                        # Add nodes that need to be contracted:
                        nodes_to_contract.extend([x for x in 
                                                  f1[m[0]][edge_label]])
                        
                        # Add all subsequent nodes that need to be contracted:
                        # ...
                        # nodes_to_contract.extend(contract_subsequent_nodes(
                        #     nodes_to_contract, T1, T2, df_A1, df_A2))
                        
                    # If the coefficient (edge label) from polynomial 1 is 
                    # found in polynomial 2, map the corresponding nodes:
                    if edge_label in f2[m[1]].keys():
                        
                        # Construct the two polynomials:
                        poly_1 = [x for x in f1[m[0]][edge_label]]
                        poly_2 = [y for y in f2[m[1]][edge_label]]
                        
                        # If the polynomials do not have same number of 
                        # coefficients:
# =============================================================================
#                         if len(poly_1) != len(poly_2):
#                             
#                             # If poly_1 has fewer elements than poly_2:
#                             if len(poly_1) < len(poly_2):
#                                 
#                                 # Adjust poly_1 coefficients:
#                                 poly_1.extend([0 for _ in range(
#                                     abs(len(poly_1) - len(poly_2)))])
#                                 
#                             else:
#                                 
#                                 # Otherwise adjust poly_2 coefficients:
#                                 poly_2.extend([0 for _ in range(
#                                     abs(len(poly_1) - len(poly_2)))])
# =============================================================================
                        
                        # Equalize poly_1 and poly_2 coefficients and 
                        # find all unique combinations of mappings:
                        print('P1 = ', poly_1)
                        print('P2 = ', poly_2)
                        
                        poly_deltas.append(abs(len(poly_1) - len(poly_2)))
                        
# =============================================================================
                        if abs(len(poly_1) - len(poly_2)) >= 25 or (len(poly_1) > 7) and (len(poly_2) > 7):
                            return [0, -1, -1, -1000, [-1, -1, -1, -1, -1], -1000, poly_deltas]
# =============================================================================
                        
                        if len(poly_1) < len(poly_2):
                            unique_combinations = [list(zip(poly_1, comb)) 
                                                   for comb in 
                                                   itertools.permutations(
                                                       poly_2, len(poly_1))]
                        else:
                            unique_combinations = [list(zip(comb, poly_2)) 
                                                   for comb in 
                                                   itertools.permutations(
                                                       poly_1, len(poly_2))]
                        
                        print("unique comb = ", unique_combinations)
                        
                        ''' These nodes are added in the hypotheses, but not in the mapping. v_i -> 0 or 0 -> w_i '''
                        
                        # Save the new unique combination of mappings for the 
                        # new node in the solutions tree:
                        unique_combinations_node_ST.append(unique_combinations)
                
                nodes_to_contract.extend([x for edge_label in 
                                          set(f2[m[1]].keys()).difference(
                                              set(f1[m[0]].keys())) 
                                          for x in f2[m[1]][edge_label]])
                
                # Add all subsequent nodes that need to be contracted:
                # subsequent_nodes_to_contract = []
                nodes_to_contract.extend(contract_subsequent_nodes(
                    nodes_to_contract, T1, T2, df_A1, df_A2))

        # Find all unique mappings at a certain depth of the search - 
        # L'(e_1) x L'(e_2) x ... x L'(e_m), where m is the number 
        # of common distinct edge labels in poly_1 and poly_2:
        unique_combination_mappings = [[y for x in pair for y in x] 
                                       for pair in itertools.product(
                                               *unique_combinations_node_ST)]
        
        # Add all subsequent nodes that need to be contracted in the unique combination 
        # mappings:
        for i, x in enumerate(unique_combination_mappings):
            
            # print(f'i = {i}, x = {x}')
            if x == []: continue
            new_nodes_to_contract_T1 = []
            new_nodes_to_contract_T2 = []
            
            # For each pair in the unique mapping:
            for y in x:
                # print("for y in x, y = ", y)
                # Do I need to contract a vertex from T2?
                if y[0] == 0:
                    
                    # If yes, contract all subsequent vertices from T2:
                    new_nodes_to_contract_T2 = contract_subsequent_nodes(
                        [y[1]], T1, T2, df_A1, df_A2)
                
                # Do I need to contract a vertex from T1?
                if y[1] == 0:
                    # print("YES y[1] for ", y[0])
                    # If yes, contract all subsequent vertices from T1:
                    new_nodes_to_contract_T1 = contract_subsequent_nodes(
                        [y[0]], T1, T2, df_A1, df_A2)
            
                # print("new_nodes_to_contract_T1 = ", new_nodes_to_contract_T1)
                # print("new_nodes_to_contract_T2 = ", new_nodes_to_contract_T2)
            
                # Add the subsequent vertex contractions to the current unique 
                # combination mapping:
                if len(new_nodes_to_contract_T1) != 0:
                    unique_combination_mappings[i].extend([(z, 0) for z in 
                                                           new_nodes_to_contract_T1])
                
                if len(new_nodes_to_contract_T2) !=0:
                    unique_combination_mappings[i].extend([(0, z) for z in 
                                                           new_nodes_to_contract_T2])
        
            # print("unique_combination_mappings = ", unique_combination_mappings)
            # print("---")
        
        # Add all additional nodes that need to be contracted:
        for x in unique_combination_mappings:
            
            # For each node to contract:
            for node_c in nodes_to_contract:
                
                # If the node is in T1:
                if node_c in T1.V and (node_c, 0) not in x: x.append((node_c, 0))
                
                # If the node is in T2:
                if node_c in T2.V and (0, node_c) not in x: x.append((0, node_c))
        
        # print("len(unique_combination_mappings)", len(unique_combination_mappings))
        
        # Construct new solution tree nodes from the unique_combinations_mappings:
        for x in unique_combination_mappings:
            
            # Add new node with mappings in the solution tree:
            ST_nodes[node_idx] = x
            
            # Add the new edge between the parent and child nodes:
            ST_edges.append([n, node_idx])
            
            # Add the index of the next node to evaluate:
            nodes_to_evaluate.append(node_idx)
            
            # Increment the node index:
            node_idx += 1
    
    ''' Find all solutions in the solutions tree: '''
    
    print(f'# ST_nodes = {len(ST_nodes)}, # ST_edges = {len(ST_edges)}')
    
    end_time = time.time()
    
    if len(ST_nodes) > 15000:
        
        return [0, len(ST_nodes), len(ST_edges), end_time - start_time, [-1, -1, -1, -1, -1], -1000, poly_deltas]
    
    # Construct adjacency matrix of Solutions Tree (ST):
    ST_adj_matrix = [[0 for j in range(len(ST_nodes.keys()))] for i in range(len(ST_nodes.keys()))]
    
    for x in ST_edges:
        ST_adj_matrix[x[0]][x[1]] = 1
    
    ST_paths = set_of_all_complete_paths_of_adj_matrix(ST_adj_matrix)

    H = []
    Hypothesis = []
    for x in ST_paths:
        H.append([z for y in x for z in ST_nodes[y]])
    
    """ Constructing hypotheses: """
    T1.l_v['v0'] = {'onto.A0'}
    T2.l_v['w0'] = {'onto.B0'}
    
    start_time_h = time.time()
    
    for x in H:
        
        """ Reset Label Sets: """
        T1.l_v = {f'v{i}' : {f'onto.A{i}'} for i in range(0, len(T1.V))}
        T2.l_v = {f'w{i}' : {f'onto.B{i}'} for i in range(0, len(T2.V))}
        
        # T1_contract = sorted(list(filter(lambda c: c[1] == 0, x)), key=(lambda k: k[0]), reverse=True)
        # T2_contract = sorted(list(filter(lambda c: c[0] == 0, x)), key=(lambda k: k[1]), reverse=True)
        no_contract = sorted(list(filter(lambda c: c[0] != 0 and c[1] != 0, x)), key=(lambda k: k[0]), reverse=True)
        
        t1_contr = [c[0] for c in no_contract if c[0] in T1.V]
        T1_contract = [(f'v{i}', 0) for i in range(len(T1.V) - 1, 0, -1) if f'v{i}' not in t1_contr]
        
        t2_contr = [c[1] for c in no_contract if c[1] in T2.V]
        T2_contract = [(0, f'w{i}') for i in range(len(T2.V) - 1, 0, -1) if f'w{i}' not in t2_contr]
        
        print()
        print("T1_contract = ", T1_contract)
        print("T2_contract = ", T2_contract)
        print("no_contract = ", no_contract)
        print()
        
        for t1 in T1_contract:
            
            L1 = list(filter(lambda item: item[0][1] == t1[0], T1.l_e.items()))[0]
            
            if len(T1.l_v[L1[0][1]]) > 1:
                s = ''
                cnt = 0
                for el in T1.l_v[L1[0][1]]:
                    if cnt + 1 == len(T1.l_v[L1[0][1]]):
                        s += f'{el})'
                    else:
                        s += f'{el} & '
                    cnt += 1
                T1.l_v[L1[0][0]].add(f'(onto.{L1[1]}.some(' + s + ')')
                # T1.l_v[L1[0][0]].add(f'{L1[1]}.some(' + s)
            elif len(T1.l_v[L1[0][1]]) == 1:
                el = list(T1.l_v[L1[0][1]])[0]
                s = f'{el}'
                T1.l_v[L1[0][0]].add(f'(onto.{L1[1]}.some(' + s + '))')
                # T1.l_v[L1[0][0]].add(f'{L1[1]}.some(' + s)
            
            
            
        for t2 in T2_contract:
            
            L2 = list(filter(lambda item: item[0][1] == t2[1], T2.l_e.items()))[0]
            
            if len(T2.l_v[L2[0][1]]) > 1:
                s = ''
                cnt = 0
                for el in T2.l_v[L2[0][1]]:
                    if cnt + 1 == len(T2.l_v[L2[0][1]]):
                        s += f'{el})'
                    else:
                        s += f'{el} & '
                    cnt += 1
                T2.l_v[L2[0][0]].add(f'(onto.{L2[1]}.some(' + s + ')')
            elif len(T2.l_v[L2[0][1]]) == 1:
                el = list(T2.l_v[L2[0][1]])[0]
                s = f'{el}'
                T2.l_v[L2[0][0]].add(f'(onto.{L2[1]}.some(' + s + '))')
        
        temp_h = []
        for t3 in no_contract:
            
            if len(T1.l_v[t3[0]]) > 1:
                c1 = ''
                cnt = 0
                for el in T1.l_v[t3[0]]:
                    if cnt + 1 == len(T1.l_v[t3[0]]):
                        c1 += f'{el}'
                    else:
                        c1 += f'{el} & '
                    cnt += 1
            elif len(T1.l_v[t3[0]]) == 1:
                if t3[0] == 'v0':
                    el = list(T1.l_v[t3[0]])[0]
                    c1 = f'{el}'
                else:
                    el = list(T1.l_v[t3[0]])[0]
                    c1 = f'{el}'
            
            if len(T2.l_v[t3[1]]) > 1:
                c2 = ''
                cnt = 0
                for el in T2.l_v[t3[1]]:
                    if cnt + 1 == len(T2.l_v[t3[1]]):
                        c2 += f'{el}'
                    else:
                        c2 += f'{el} & '
                    cnt += 1
            elif len(T2.l_v[t3[1]]) == 1:
                if t3[1] == 'w0':
                    el = list(T2.l_v[t3[1]])[0]
                    c2 = f'{el}'
                else:
                    el = list(T2.l_v[t3[1]])[0]
                    c2 = f'{el}'
            
            temp_h.append((c2, c1))
        
        Hypothesis.append(temp_h)
    
    end_time_h = time.time()
        
    return [0, len(ST_nodes), len(ST_edges), end_time - start_time, Hypothesis, 
            end_time_h - start_time_h, poly_deltas]
# =============================================================================

# Function to find the all possible permutations
def permutations(res,nums,l,h):
    # Base case
    # Add the vector to result and return
    if l==h:
        res.append(nums[:])
        return

    # Permutations made
    for i in range(l,h+1):
        nums[l],nums[i]=nums[i],nums[l]
        # Calling permutations for
        # next greater value of l
        permutations(res,nums,l+1,h)
        nums[l],nums[i]=nums[i],nums[l]

# Function to get the all possible permutations
def permute(nums):
    res = []
    x = len(nums)-1
    # Calling permutations for the first
    # time by passing l
    # as 0 and h = nums.size()-1
    permutations(res,nums,0,x)
    return res
