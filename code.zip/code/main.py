# =============================================================================
""" Libraries: """
import numpy as np
import pandas as pd
import time
from functools import reduce
from owlready2 import *
import types

from functions import print_matrix
from functions import print_dict
from functions import create_non_entailment_concepts_1
from functions import find_max_freq_of_common_edge_labels_on_same_depths
from functions import get_avg_edge_labels_branching_factor
from pathfinder import pathfinder
from pathfinder import set_of_all_complete_paths
from isomorphisms import find_isomorphisms_v5


owlready2.JAVA_EXE = "C:\\Program Files\\Java\\jdk-20\\bin\\java.exe"
# =============================================================================

# =============================================================================
""" Description Tree class: """
class DescriptionTree:
    
# -----------------------------------------------------------------------------
    def __init__(self, name, root, V, E):
        
        """ E.g. name = 'T1' """
        self.name = name
        
        """ E.g. root = 'v0' """
        self.root = root
        
        """ E.g.: 
                V = {'v0', 'v1', 'v2', ...}
                l_v = {'v0': 'T', 'v1': 'T', 'v2': 'T', ...}
        """
        self.V, self.l_v = set(V.keys()), V
        
        """ E.g.: 
                Vm = {'v0' : 0, 'v1' : 1, 'v2' : 2, ...}
        """
        self.Vm = dict(map(lambda x: (x, int(x[1:])), self.V))
        
        """ E.g.: 
                E = {('v0', 'v1'), ('v0', 'v2'), ...}
                l_e = {('v0', 'v1'): 'r', ('v0', 'v2'): 'r', ...}
        """
        self.E, self.l_e = set(E.keys()), E
        
        """ E.g.: 
                Em = {('v0', 'v1') : (0, 1), ('v0', 'v2') : (0, 2), ...}
                En = {(0, 1), (0, 2), (1, 3), ...} 
        """
        self.Em = dict(map(lambda x: ((x[0], x[1]), 
                                      (int(x[0][1:]), int(x[1][1:]))), self.E))
        self.En = set(self.Em.values())
        
        """ ... """
        self.set_vertex_depths(self.Vm, self.En)  # E.g.: {'v0': 0, 'v1': 1, 'v2': 1, ...}
        
        # """ Set leaves of the tree: """
        # self.leaves = [f'{self.root[0]}{idx}' 
        #           for idx, v in enumerate(self.adjacency_matrix()) 
        #           if set(v) == {0}]
# -----------------------------------------------------------------------------

# =============================================================================
# -----------------------------------------------------------------------------
    def width(self):
        children = {vertex : [] for vertex in self.V}
        
        for arc in self.E:
            children[arc[0]].append(arc[1])
        
        num_vertices_depths = {i : [] for i in range(max(self.depths.values()) + 1)}
        
        # print(num_vertices_depths)
        
        for vertex, vertex_depth in self.depths.items():
            num_vertices_depths[vertex_depth].append(vertex)
                
        width = max([len(vertices) for vertices in num_vertices_depths.values()])
        
        # print(num_vertices_depths)
        
        return width
# -----------------------------------------------------------------------------
# =============================================================================

# =============================================================================
# -----------------------------------------------------------------------------
    def branching_factor(self):
        children = {vertex : [] for vertex in self.V}
        
        for arc in self.E:
            children[arc[0]].append(arc[1])
        
        # print(children)
        
        min_branching_factor = min([len(vertices) for vertices in children.values()])
        
        max_branching_factor = max([len(vertices) for vertices in children.values()])
        
        branches = [len(vertices) for vertices in children.values()]
        
        return [min_branching_factor, max_branching_factor, branches, np.mean(branches), np.std(branches)]
# -----------------------------------------------------------------------------
# =============================================================================

# =============================================================================
# -----------------------------------------------------------------------------
    def branching_factor_edges(self):
        edge_depths = { (self.depths[edge[0]] + self.depths[edge[1]]) / 2: [] for edge, label in self.l_e.items()}
        
        for edge, label in self.l_e.items():
            edge_depths[(self.depths[edge[0]] + self.depths[edge[1]]) / 2].append(label)
        
        # print(edge_depths)
        
        return edge_depths
# -----------------------------------------------------------------------------
# =============================================================================

# -----------------------------------------------------------------------------
    def incidence_matrix(self):
        I = np.array([[0 for i in range(len(list(self.l_e.values())))] 
                      for j in range(len(self.V))])
        
        enumerated_edges = dict()
        
        n = 0
        for x in self.l_e.items():
            
            if x[1] not in enumerated_edges.keys():
                
                enumerated_edges[x[1]] = n
                
                n += 1
        
        for v, e in self.l_e.items():
            
            I[int(v[0][-1])][enumerated_edges[e]] = 1
            I[int(v[1][-1])][enumerated_edges[e]] = 1
        
        return I
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
    def incidence_matrix_v1(self):
        data = np.array([[0 for i in range(len(list(self.l_e.values())))] 
                      for j in range(len(self.V))])
        
        enumerated_edges = dict()
        
        n = 0
        for x in self.l_e.items():
            
            if x[1] not in enumerated_edges.keys():
                
                enumerated_edges[x[1]] = n
                
                n += 1
        
        # print("enumerated_edges", enumerated_edges)
        
        for v, e in self.l_e.items():
            
            data[int(v[0][-1])][enumerated_edges[e]] = 1
            data[int(v[1][-1])][enumerated_edges[e]] = 1
        
        # print("data", data)
        
        I = pd.DataFrame(data=data, index=list(range(0, len(self.V))), 
                         columns=list(self.l_e.values()))
        
        return I
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
    def adjacency_matrix(self):
        A = np.array([[0 for i in range(len(self.V))] 
                      for j in range(len(self.V))])
        
        for e in self.En:
            
            A[e[0]][e[1]] = 1
        
        return A
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
    def adjacency_matrix_v1(self):
        data = [[0 for i in range(len(self.V))] for j in range(len(self.V))]
        
        for e in self.En:
            
            # data[e[0]][e[1]] = 1
            # deg = sum(self.adjacency_matrix()[e[0]])
            # data[e[0]][e[1]] = f'{deg}' + self.l_e[(f'{self.root[0]}{e[0]}', 
            #                              f'{self.root[0]}{e[1]}')]
            
            data[e[0]][e[1]] = self.l_e[(f'{self.root[0]}{e[0]}', 
                                         f'{self.root[0]}{e[1]}')]
        
        # A = pd.DataFrame(data=data, index=sorted(list(self.V)), 
        #                  columns=sorted(list(self.V)))
        
        A = pd.DataFrame(data=data, index=[f'{self.root[0]}{value_idx}' for value_idx in range(0, len(self.V))], 
                         columns=[f'{self.root[0]}{value_idx}' for value_idx in range(0, len(self.V))])
        
        return A
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------    
    def set_vertex_depths(self, Vm, En):
        
        # Initialize the depths variable:
        self.depths = dict()
        
        # Initialize the depth of the root:
        self.depths[self.root] = 0
        
        # Get the reversed mapping of vertices:
        Vm_reversed = {int(val) : key for key, val in Vm.items()}
        
        # Iterate over all edges and get all nodes to define their depths:
        for n1, n2 in sorted(list(En)):
            
            # Construct the vertices:
            vertex1 = Vm_reversed[n1]
            vertex2 = Vm_reversed[n2]
            
            # Define the depth of the vertex:
            self.depths[vertex2] = self.depths[vertex1] + 1
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
    def toString(self):
        print(f'{self.name} := (V = {self.V}, E = {self.E}, {self.root})')
        print(f'l(v) := {self.l_v}')
        print(f'l(e) := {self.l_e}')
# -----------------------------------------------------------------------------
# =============================================================================

# =============================================================================
""" Tests (main function): """

''' Simulation for evaluation: '''
df = pd.DataFrame()
description_trees = []  # .append((T1, T2))
number_V1_vertices = []  # .append(len(T1.V))
number_V2_vertices = []  # .append(len(T2.V))
number_E1_edges = []  # .append(len(T1.E))
number_E2_edges = []  # .append(len(T2.E))
number_E1_labels = []  # .append(len(set(T1.l_e.values())))
number_E2_labels = []  # .append(len(set(T2.l_e.values())))
number_of_hypotheses = []  # .append(len(mapping[0]))
algorithm_time = []  # .append(time.time() - start_time)
number_common_labels = []
number_uncommon_labels = []
freq_edge_labels_T1 = []
freq_edge_labels_T2 = []
max_freq_edge_labels_T1 = []
max_freq_edge_labels_T2 = []
number_ST_nodes = []
number_ST_edges = []
c1_expr = []
c2_expr = []
time_to_generate_hypotheses = []
total_time = []
max_freq_common_edge_labels_same_depths = []
num_h_formula = []
T_models = []
T_union_H_models = []
hypotheses_for_case = []

depth_of_T1 = []
depth_of_T2 = []
height_of_T1 = []
height_of_T2 = []
width_of_T1 = []
width_of_T2 = []
branching_factor_T1 = []
branching_factor_T2 = []

min_branching_factor_T1 = []
max_branching_factor_T1 = []
mean_branching_factor_T1 = []
std_branching_factor_T1 = []

min_branching_factor_T2 = []
max_branching_factor_T2 = []
mean_branching_factor_T2 = []
std_branching_factor_T2 = []

branches_T1 = []
branches_T2 = []

common_edge_labels = []

poly_deltas = []

# Generate description trees:
import random

''' This part can be modified so that the parameters of the simulation are 
    changed:
        
        a, b -> lower and upper bound of number of vertices in description 
                trees
        c, d -> lower and upper bound of number of edge labels in description 
                trees
        
        e = 1 -> always equals 1 (|E| = |V| - e)
'''
# Define number of random vertices:
a, b = 1, 10
c, d = 1, 10
e = 1  # starting point of num_random_parts

number_of_simulations = 130
version = 1

''' Provide the file path in which the ontologies and the simulation results will be saved '''
file_path = input("Input the complete path of the folder in which the simulations results will be saved: ")
file_path += '\\'

for _ in range(number_of_simulations):
    # Get random number of vertices:
    num_vertices_T1 = random.randint(a, b)
    num_vertices_T2 = random.randint(a, b)
    
    # Generate random vertex sets with labels:
    V1 = {f'v{i}' : {f'onto.A{i}'} for i in range(0, num_vertices_T1)}
    V2 = {f'w{i}' : {f'onto.B{i}'} for i in range(0, num_vertices_T2)}
    
    # Generate random edge sets with labels:
    num_labels_T1 = random.randint(c, d)
    num_labels_T2 = random.randint(c, d)
    
    E1_labels = [f'r{i}' for i in range(0, num_labels_T1)]
    E2_labels = [f'r{i}' for i in range(0, num_labels_T2)]
    
    E1, E2 = dict(), dict()
    
    # Divide edge connections into n random parts:
    x = len(list(V1.keys())) - e
    if x == 0:
        num_random_parts = [0]
    else:
        num_random_parts = [random.randint(1, x)]
        x = abs(x - num_random_parts[-1])
        while x != 0:
            y = random.randint(1, len(list(V1.keys())) - sum(num_random_parts) - 1)
            num_random_parts.append(y)
            x = abs(x - y)
            if x == 0: break
    
    for i, x in enumerate(num_random_parts):
        # print(sum(num_random_parts[:i]), sum(num_random_parts[:i+1]))
        for j in range(sum(num_random_parts[:i]) + 1, sum(num_random_parts[:i + 1]) + 1):
            if f'v{i}' != f'v{j}':
                E1[(f'v{i}', f'v{j}')] = random.choice(E1_labels)
    
    # Divide edge connections into n random parts:
    x = len(list(V2.keys())) - 1
    if x == 0:
        num_random_parts = [0]
    else:
        num_random_parts = [random.randint(1, x)]
        x = abs(x - num_random_parts[-1])
        while x != 0:
            y = random.randint(1, len(list(V2.keys())) - sum(num_random_parts) - 1)
            num_random_parts.append(y)
            x = abs(x - y)
            if x == 0: break
    
    for i, x in enumerate(num_random_parts):
        for j in range(sum(num_random_parts[:i]) + 1, sum(num_random_parts[:i + 1]) + 1):
            if f'w{i}' != f'w{j}':
                E2[(f'w{i}', f'w{j}')] = random.choice(E2_labels)
    
    # Generate T1:
    T1 = DescriptionTree(name='T1', root='v0', 
                          V=V1, 
                          E=E1)
    
    # Generate T2:
    T2 = DescriptionTree(name='T2', root='w0', 
                          V=V2, 
                          E=E2)
    
    """ Create concepts (string) for non-entailment: """
    concept_1, concept_2 = create_non_entailment_concepts_1(T1, T2)
    
    print("concept_1 = ", concept_1)
    print("concept_2 = ", concept_2)
    
    T1.l_v = {f'v{i}' : {f'onto.A{i}'} for i in range(0, num_vertices_T1)}
    T2.l_v = {f'w{i}' : {f'onto.B{i}'} for i in range(0, num_vertices_T2)}
    
    print()
    T1.toString()
    print()
    T2.toString()
    print()
    
    description_trees.append((T1, T2))  # .append((T1, T2))
    number_V1_vertices.append(len(T1.V))  # .append(len(T1.V))
    number_V2_vertices.append(len(T2.V))  # .append(len(T2.V))
    number_E1_edges.append(len(T1.E))  # .append(len(T1.E))
    number_E2_edges.append(len(T2.E))  # .append(len(T2.E))
    number_E1_labels.append(len(set(T1.l_e.values())))  # .append(len(set(T1.l_e.values())))
    number_E2_labels.append(len(set(T2.l_e.values())))  # .append(len(set(T2.l_e.values())))
    number_common_labels.append(len(set(T1.l_e.values()).intersection(set(T2.l_e.values()))))
    number_uncommon_labels.append(len(set(T1.l_e.values()).difference(set(T2.l_e.values()))) + 
                                  len(set(T2.l_e.values()).difference(set(T1.l_e.values()))))
    max_freq_c_e_eq_d = find_max_freq_of_common_edge_labels_on_same_depths(T1, T2)
    max_freq_common_edge_labels_same_depths.append(max_freq_c_e_eq_d[1])
    num_h_formula.append(max_freq_c_e_eq_d[2])
    height_of_T1.append(max(T1.depths.values()))
    height_of_T2.append(max(T2.depths.values()))
    width_of_T1.append(T1.width())
    width_of_T2.append(T2.width())
    
    branches_T1.append(T1.branching_factor()[2])
    branches_T2.append(T2.branching_factor()[2])
    
    min_branching_factor_T1.append(T1.branching_factor()[0])
    max_branching_factor_T1 += [T1.branching_factor()[1]]
    mean_branching_factor_T1 += [T1.branching_factor()[3]]
    std_branching_factor_T1 += [T1.branching_factor()[4]]
    
    min_branching_factor_T2.append(T2.branching_factor()[0])
    max_branching_factor_T2 += [T2.branching_factor()[1]]
    mean_branching_factor_T2 += [T2.branching_factor()[3]]
    std_branching_factor_T2 += [T2.branching_factor()[4]]
    
    common_edge_labels.append(len(set(T1.l_e.values()).intersection(set(T2.l_e.values()))))
    
    # freq_edge_labels.append(...)
    if len(list(T1.l_e.values())) != 0:
        max_freq_edge_labels_T1.append(reduce(lambda y, z: y if y[1] > z[1] else z, 
                                         [(x, list(T1.l_e.values()).count(x)) for x in 
                                   set(list(T1.l_e.values()))]))
    else:
        max_freq_edge_labels_T1.append(0)
    
    if len(list(T2.l_e.values())) != 0:
        max_freq_edge_labels_T2.append(reduce(lambda y, z: y if y[1] > z[1] else z, 
                                         [(x, list(T2.l_e.values()).count(x)) for x in 
                                   set(list(T2.l_e.values()))]))
    else:
        max_freq_edge_labels_T2.append(0)
    
    df = pd.DataFrame()
    
    ''' find_isomorphisms_v5 is the compute_isomorphisms function 
        (construct_polys, equalize_polys, and construct_hypotheses 
         are directly implemented in this function). 
    '''
    mapping = find_isomorphisms_v5(T1, T2)
    
    algorithm_time.append(mapping[3])
    number_ST_nodes.append(mapping[1])
    number_ST_edges.append(mapping[2])
    time_to_generate_hypotheses.append(mapping[5])
    total_time = mapping[3] + mapping[5]
    
    poly_deltas.append(mapping[6])
    
    Hypotheses = mapping[4]
    number_of_hypotheses.append(len(Hypotheses))
    
    """ CREATING THE ONTOLOGY FOR TESTING: """
    before_hypothesis, after_hypothesis = [], []
    i = 0
    flag_expr = True
    if len(Hypotheses) <= 24:
        for h in Hypotheses:
            print(f'i, version : i = {i}, version = {version}')
            
            prefix = f'onto{i}-{version}.'
            
            onto = get_ontology(f'http://hypothesis{version}.org/onto{i}-{version}.owl')
            
            with onto:
                
                object_properties_from_T1 = [role for role in set(T1.l_e.values())]
                object_properties_from_T2 = [role for role in set(T2.l_e.values())]
                
                classes_from_T1 = [concept[5:] for concepts in T1.l_v.values() for concept in concepts if len(concept) == 7 or 
                                   len(concept) == 8]
                classes_from_T2 = [concept[5:] for concepts in T2.l_v.values() for concept in concepts if len(concept) == 7 or 
                                   len(concept) == 8]
                
                ''' Create roles: '''
                if len(set(object_properties_from_T1 + object_properties_from_T2)) != 0:
                    for role in set(object_properties_from_T1 + object_properties_from_T2):
                        types.new_class(role, (ObjectProperty, ))
                
                ''' Create concepts: '''
                for concept in classes_from_T1:
                    types.new_class(concept, (Thing, ))
                
                for concept in classes_from_T2:
                    types.new_class(concept, (Thing, ))
                
                """ Generate concepts in the non-entailment: """
                class_1 = types.new_class('C1', (Thing, ))
                class_2 = types.new_class('C2', (Thing, ))

                if flag_expr == True:
                    c1_expr.append(concept_1)
                    c2_expr.append(concept_2)
                    flag_expr = False
                class_1.equivalent_to.append(eval(concept_1))
                class_2.equivalent_to.append(eval(concept_2))
                
                for h1 in h:
        
                    # gca = GeneralClassAxiom(eval(h1[0])) # Left side
                    gca = GeneralClassAxiom(eval(h1[0]) & Thing)
                    C1 = eval(h1[1])
                    C2 = eval(h1[0])
                    # gca1 = GeneralClassAxiom(C1)
                    gca.is_a.append(C1)

                if class_2 not in list(class_1.descendants()):
                    before_hypothesis.append(False)
                
                sync_reasoner(onto)
                    
                if class_2 in list(class_1.descendants()):
                    after_hypothesis.append(True)
            
            onto.save(file = file_path + f"{version - 1} - onto{i + 1}.owl", format = "rdfxml")
            
            onto.destroy(update_relation = True, update_is_a = True)
            i += 1
    
        before_H = reduce(lambda p1, p2: p1 and p2, before_hypothesis)
        after_H = reduce(lambda p1, p2: p1 and p2, after_hypothesis)
    else:
        before_H = False
        after_H = None
        
        if flag_expr == True:
            c1_expr.append(concept_1)
            c2_expr.append(concept_2)
            flag_expr = False
    
    hypotheses_for_case.append(Hypotheses)
    T_models.append(before_H)
    T_union_H_models.append(after_H)

    df['C1'] = c1_expr
    df['C2'] = c2_expr
    df['Hypotheses'] = hypotheses_for_case
    df['# V1'] = number_V1_vertices
    df['# V2'] = number_V2_vertices
    df['# e in E1 and E2'] = common_edge_labels
    df['# ST nodes'] = number_ST_nodes
    df['max f(e), e in E1 & E2 & d1(e) = d2(e)'] = max_freq_common_edge_labels_same_depths
    df['h(T1)'] = height_of_T1
    df['h(T2)'] = height_of_T2
    df['w(T1)'] = width_of_T1
    df['w(T2)'] = width_of_T2
    
    df['min BF T1'] = min_branching_factor_T1
    df['min BF T2'] = min_branching_factor_T2
    df['max BF T1'] = max_branching_factor_T1
    df['max BF T2'] = max_branching_factor_T2
    df['mu BF T1'] = mean_branching_factor_T1
    df['mu BF T2'] = mean_branching_factor_T2
    df['sigma BF T1'] = std_branching_factor_T1
    df['sigma BF T2'] = std_branching_factor_T2
    
    df['branches T1'] = branches_T1
    df['branches T2'] = branches_T2
    
    df['poly_deltas'] = poly_deltas
    
    df['# H formula (formula is not finalized)'] = num_h_formula
    df['# H'] = number_of_hypotheses
    df['t_i [s] to find isomorphisms'] = algorithm_time
    df['t_h [s] to generate hypotheses'] = time_to_generate_hypotheses
    df['T |= C2 SubClassOf C1'] = T_models
    df['T U H |= C2 SubClassOf C1'] = T_union_H_models

    version += 1

df['t [s] = t_i + t_h'] = df['t_i [s] to find isomorphisms'] + df['t_h [s] to generate hypotheses']

df.to_html(file_path + f'{version} - Simulation_{version} - parameters - a_{a} - b{b} - c{c} - d{d} - e{e}.html')
df.to_csv(file_path + f'{version} - Simulation_{version} - parameters - a_{a} - b{b} - c{c} - d{d} - e{e}.csv')
