import pandas as pd
import seaborn as sns
from scipy.stats import norm
import matplotlib.pyplot as plt
import numpy as np
import ast


FILE_PATH_SIMULATION = input("Input the complete path of the folder in which the simulations results are saved (.csv file): ")

df = pd.read_csv(FILE_PATH_SIMULATION)



df['max f(e), e in E1 & E2 & d1(e) = d2(e)'] = df['max f(e), e in E1 & E2 & d1(e) = d2(e)'].apply(lambda el: ast.literal_eval(el))
df['x_axis'] = df['max f(e), e in E1 & E2 & d1(e) = d2(e)'].apply(lambda elem: round(np.mean([p[1] for p in elem]), 2) if len(elem) != 0 else 0)

df['Hypotheses'] = df['Hypotheses'].apply(lambda el: ast.literal_eval(el))

df_results = pd.DataFrame(index=['df'])

df_results['mean | median | IQR # V1'] = [round(np.mean(df['# V1']), 2), 
                                           
                                           round(np.median(df['# V1']), 2), 
                                           
#                                            round(np.max(df['# V1']), 2) - round(np.min(df['# V1']), 2)], 
                                           round(np.percentile(df['# V1'], 75), 2) 
                                            - round(np.percentile(df['# V1'], 25), 2)],

df_results['mean | median | IQR # V2'] = [round(np.mean(df['# V2']), 2), 
                                           
                                           round(np.median(df['# V2']), 2), 
                                           
#                                            round(np.max(df['# V2']), 2) - round(np.min(df['# V2']), 2)], 
                                           round(np.percentile(df['# V2'], 75), 2) 
                                            - round(np.percentile(df['# V2'], 25), 2)],

df_results['mean | median | IQR #H'] = [round(np.mean(df['# H']), 2), 
                                         
                                           round(np.median(df['# H']), 2), 
                                         
#                                            round(np.max(df['# H']), 2) - round(np.min(df['# H']), 2)], 
                                         round(np.percentile(df['# H'], 75), 2) 
                                            - round(np.percentile(df['# H'], 25), 2)],

card_H_110 = []
for x in df['Hypotheses']:
    for y in x:
        card_H_110.append(len(y))
        
df_results['mean | median | IQR |H|'] = [round(np.mean(card_H_110), 2), round(np.median(card_H_110), 2), 
                                        round(np.percentile(card_H_110, 75), 2) - round(np.percentile(card_H_110, 25), 2)],

df_results['mean | median | max t [s]'] = [round(np.mean(df['t [s] = t_i + t_h']), 3), 
                                            round(np.median(df['t [s] = t_i + t_h']), 3), 
                                            round(np.max(df['t [s] = t_i + t_h']), 3)],

pos = 0
for x in df['T U H |= C2 SubClassOf C1']:
    if x == True:
        pos += 1
prob_pos_110 = round((pos / len(df['T U H |= C2 SubClassOf C1'])) * 100, 2)

df_results['P(T U H |= C2 SubClassOf C1 | Check is made)'] = [prob_pos_110]

print(df_results)

import math

sns.set(font_scale=1)
fsize = (5, 2)

fig = plt.figure(figsize=fsize)
# plt.title('avg |H|(avg max f(e), e in E1 & E2 & d1(e) = d2(e))')
ax = sns.scatterplot(data=df, x=df['x_axis'], y='# H', hue='# H', palette="coolwarm")
# ax = sns.barplot(data=df_1120, x=df_1120['x_axis'], y='# H', hue='# H')
# ax = sns.barplot(data=df_2130, x=df_2130['x_axis'], y='# H', hue='# H')
ax.set(xlabel='mean of max repetition of common edge label', ylabel='# H')
# ax.set_xlim(1, 4.1)
plt.legend(bbox_to_anchor=(1.02, 1), loc='upper left', borderaxespad=0, title='# H')
plt.show()
